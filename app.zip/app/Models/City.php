<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    protected $fillable = ['city', 'state_id', 'status'];
    public $timestamps = false;

    public function state()
    {
        return $this->belongsTo(State::class);
    }
}
